    <footer class="blog-footer">
      <p>Blog napravila Zorica.</p>
      <p>
        <a href="#">Nazad na vrh</a>
      </p>
    </footer>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  </body>
</html>
